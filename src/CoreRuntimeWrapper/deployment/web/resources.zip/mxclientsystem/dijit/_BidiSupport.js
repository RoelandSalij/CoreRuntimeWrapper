//>>built
define("dijit/_BidiSupport",["dojo/has","./_WidgetBase","./_BidiMixin"],function(_1,_2,_3){
_2.extend(_3);
_1.add("dojo-bidi",true);
return _2;
});
