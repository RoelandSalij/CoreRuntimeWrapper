//>>built
define("dijit/form/nls/ar/ComboBox",({previousMessage:"الاختيارات السابقة",nextMessage:"مزيد من الاختيارات"}));
